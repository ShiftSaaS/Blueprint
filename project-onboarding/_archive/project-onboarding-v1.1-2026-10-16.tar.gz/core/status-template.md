<!-- Reference instance copied from Lintent/Code/docs/execution/status-patterns/template.md (status layout v1.7) on 2026-10-15 (blueprint v1). Replace project-specific names (PAC, PAC_, P0.x, paths) when instantiating. -->

# Status template — v1.7

Replace placeholders with evidence-backed content. This is a template, not a live status file.
Use the heading that matches the file name picked in [states.md](states.md).

| Block | What each must show and its rule |
|---|---|
| Header · action card · ROAD · PAST · CURRENT · AGENTS · HANDOFFS · FUTURE | [README → The status file, block by block](README.md#the-status-file-block-by-block) |
| PHASE, ACTIVITY, file name | [states.md](states.md) |

~~~~markdown
# Waiting for your action

> Updated: {actual timestamp and timezone} · Pattern: status-patterns v1.7
> Shared rules: {relative link to status-patterns/README.md}

> **👤 YOU ACT** — **{plain action, with the exact command}**
> {or: **⚙️ AGENT ACTS · {tool} ({repo})** — **{what it does now}** / You: nothing needed right now}

| | |
|---|---|
| **Task** | `{ID}` · {variants V1–V6, two-word gloss} |
| **Flow** | ● {ANALYSIS_N} ── ● {DECISION_N} ── ● Board ▸ ● {Phase} ── ◉ **{current Phase}** ── ○ {Phase} ── ○ Done |
| **Next** | {from} → {to} — {the Blueprint condition or command} |

| Type | Does |
|---|---|
| **`{known command}`** | {what it does} (recommended) |
| **`{second known command}`** | {what it does} |

```text
{PROJECT} · SESSION HANDOFF
Project state: {one sentence}
Active task: {real task ID or None}

ROAD · {strategy}   (stages in run order = the stage Index, R-05)
 ✓ {done stage}    {what it delivered, a few words}
 ● {open stage}    {what it is for — progress}
 ▶ YOU ARE HERE
 🛑 HARD STOP      {what is blocked} — set by {decision} · moved {N}×: {history}; to move: {who, how}   (or ◆ / ⏸ gate)
 ⏸ {waiting item}  {what it waits for · until}
 ◆ {decision point} {the question}
 ○ {later step}    {what}
 Legend: ✓ done · ● open · ▶ you are here · 🛑 hard stop · ⏸ waiting · ◆ decision point · ○ not yet
 Deferred: {items, until}   (or omit)

PAST
│
├─ Older entries, moved verbatim: [history/](history/)
│
│
├─ ✓ {milestone} · {actual date/time, or date with time unknown}
│  👤 HUMAN: {actual action; omit if none}
│  ⚙️ AI:    {actual action; omit if none}
│  RESULT:  {observed result, including limitations that affect next steps}
│  RECORD:  {task/evidence path and real commit if available}
│
▼
╔══════════════════════════════════════════════════════════════════════╗
║ CURRENT — {plain action title}                                    ║
╚══════════════════════════════════════════════════════════════════════╝
│  STOP:         {only when a hard stop or gate applies: what it blocks, what lifts it, how often it moved}
│  PHASE:        {one value from states.md}
│  TASK:         {ID or None}
│  ACTIVITY:     {RUNNING / WAITING_USER / WAITING_EXTERNAL / IDLE}
│  NEXT ACTOR:   {HUMAN / AI / named external dependency}
│  NEXT ACTION:  {one concrete action; identify scope}
│  👤 HUMAN:     {needed decision or No action currently required}
│  ⚙️ AI:        {running action or available support; distinguish clearly}
│  ADVANCE WHEN: {observable completion/transition condition}
│
▼
AGENTS — all three repos (a view of their status files; refreshed at every status update)
│  Code     {agent} · {PHASE} · {task}      → {NEXT ACTOR}: {NEXT ACTION}      {ACTIVE when IN_PROGRESS.md}
│  API      {agent} · {PHASE} · {task}      → {NEXT ACTOR}: {NEXT ACTION}
│  Landing  {agent} · {PHASE} · {task}      → {NEXT ACTOR}: {NEXT ACTION}
│
▼
HANDOFFS — open cross-repo work only (done → PAST)
│  ⇄ PENDING for {repo}: {what} — {source} · since {date}
│  ⇄ picked up as {ID} · {date}: {what} — from {repo}
│  {or: none open}
│
▼
FUTURE — trigger conditions, not scheduled
│
└─ {condition} → {actor + action} → {expected outcome}
   If unsuccessful → {specific recovery or blocker handling}
```
~~~~
