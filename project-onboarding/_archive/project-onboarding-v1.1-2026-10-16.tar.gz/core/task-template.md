<!-- Reference instance copied from PAC/Source/docs/execution/task-template.md on 2026-10-15 (blueprint v1). Replace project-specific names (PAC, PAC_, P0.x, paths) when instantiating. -->

# PX.Y — <title: a compressed statement of the ROOT>

> Initiative: <P0.x setup | P1.x CR | …> · Origin: <PAC_DECISION_N (item) | JIRA MDDIPAC-NNN | review of <parent>> ·
> Repos: <migration-pac | migration-pac-admin | migration-pac-schedule | workstation | hub> · Runs on: <owner's Windows machine | AI>

Files / locations: <paths this task will touch or inspect — `repo/path`>

Create this file as `specs/tasks/PX.Y-slug.md` while open; convert to `PX.Y-slug/README.md` only on verified closure
([conventions §6](conventions.md#6-closing-a-task)). Adjust relative links when copying.

## Change

What is wrong or missing and why (quote the owner or the source).
**Confirmed before building:** what reading the source / handover doc / evidence showed — exact `repo/path:line`.
**Scope, one PROXY:** the single change or investigation, precise enough to carry out.
**Explicitly deferred:** adjacent findings, and where they went (open-questions / task ID).

## Why

One paragraph: the underlying principle.

## Golden Thread (ROOT → Change)

```text
ROOT
"<general principle>"
    │  <how it applies to this task / who raised it>
    ▼
LOCATE (src)
"<exact locations>"
    │  <supporting detail; no conclusion yet>
    ▼
AS-BUILT EVIDENCE (<source>)          ← or INVESTIGATION / EVIDENCE TO ESTABLISH + DECISION GATE
"<what was observed>"
    ▼
VIOLATION IDENTIFIED
"<only what the evidence establishes>"
    ▼
PROXY (<title>)
"<intended behavior, no implementation detail>"
    ▼
CONCRETE CHANGE
see "## Change" above
```

## Task path

> Origin: <…> · Planned: READY → DISCUSSING → EXECUTING → VERIFYING → CLOSING · Actual: <written at the close>

## Done when

- [ ] <observable criterion> — evidence: <file that will show it>
- [ ] Limitations explicit.

## Owner checks

| # | Question | Answer (owner's words) |
|---|---|---|
| A | … | *(unanswered — never filled by the AI)* |

## Live progress

PAST → CURRENT → FUTURE, `👤 HUMAN` / `⚙️ AI` lines, same turn as the status file.

## As-built evidence

Pending until execution. Never placeholders; never secrets.

## Status

Scoped <date>, not implemented. Say `implement PX.Y` to authorize.
