# Profile — product-build

**Use when:** the owner owns the repositories and the work comes from product hypotheses (reference: Lintent — Code, API, Landing).

| Adds to core | Detail |
|---|---|
| Docs inside each repo | `docs/` per repo; one repo hosts the hub (`handoff/README.md`) for all |
| Strategy register | One register (wedge strategy, S-numbers); sibling repos name the strategy they serve |
| Stages | `STAGE_N_tasks|validation.md` before the first Golden Thread of a TASKS/VALIDATION decision |
| Cross-repo sync | Write-through of sibling board rows, or `⇄ PENDING for <repo>` lines; greeting reads siblings |
| Review by another agent | R-09: after close, the other tool reviews read-only; verified defects → sub-tasks `<ID>.N` |
| Evidence | UI screenshots (owner drops files, says `added`), tests, curl / `.http` files for services |
| Release | Deploys to the owner's cloud only with `approve live <ID>: <action>` |

Reference instance: `/Users/macbook/Documents/Work/Lintent/{Code,API,Landing}` — `AGENTS.md`, `Code/handoff/`, `Code/docs/execution/`.
