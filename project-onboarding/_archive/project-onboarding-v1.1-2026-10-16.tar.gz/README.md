# Project onboarding blueprint — v1

| | |
|---|---|
| **What** | The reusable procedure for starting work on a new software project from whatever materials exist, plus the templates it uses |
| **Called by** | Claude skill `project-onboarding` (say "use project-onboarding for <folders>") — the skill holds the procedure; this folder holds the full templates and reference instances |
| **Built from** | Lintent (product build) and PAC Online (client delivery + multi-host execution), 2026-10-15 |
| **Version** | v1.1 · 2026-10-15 (greeting + load checklist + custom profile). Projects record the version they were onboarded with; change this folder first, bump the version, then the skill |

## Layout

```text
project-onboarding/
├── README.md                       this file
├── AGENTS.md / CLAUDE.md           greeting rule when a session is opened here ("hi" → usage guide + checklist)
├── CHECKLIST.md                    load checklist A–H + decision matrix (Product · Client · multi-host · Custom/lite)
├── SKILL.md                        copy of the skill text (the saved skill is the one that runs)
├── core/                           every project
│   ├── AGENTS.reference.md         rule file (PAC instance)
│   ├── docs-README.reference.md    docs tree, workflow, naming, what was kept/dropped
│   ├── conventions.reference.md    known commands, Golden Thread, evidence, closing, commits, action card
│   ├── task-template.md
│   ├── status-template.md          PAST → CURRENT → FUTURE layout (Lintent v1.7)
│   └── golden-thread-guide.md      shapes of the Golden Thread (Lintent)
├── profiles/
│   ├── product-build.md            Lintent-style
│   ├── client-delivery.md          PAC-style
│   ├── multi-host-exec.md          record host ≠ execution host
│   └── custom.md                   core-lite and how to draft a new profile
└── multi-host/
    ├── lib/PacRun.psm1             run folder, manifest, SHA-256, masking
    ├── windows-scripts.reference.md  script standard + approval classes
    ├── APPROVALS.template.md
    └── examples/P0.1, P0.2         real scripts (install/check, round trip)
```

## Use

0. Say "hi" (in a session opened in this folder, or by invoking the skill without folders) → usage guide + checklist.
1. Owner: "use project-onboarding for <folder A>, <folder B>" (any materials — the skill classifies them by source class).
2. The skill answers "what do I need to set up" in chat, then offers to generate the hub from `core/` + the chosen `profiles/`.
3. Reference instances stay where they are: PAC `…/Temus/PAC/Source/`, Lintent `…/Documents/Work/Lintent/`.

## Not yet

- No git here yet: run `git init` in this folder yourself if you want history (this session cannot delete git lock files).
- Lintent has not been re-based on this blueprint; compare before changing it.

## History

- **2026-10-15** — v1 created at the owner's request (translated from Vietnamese: "this analysis should be a blueprint kept apart,
  somewhere on the MacBook to call up, because when I started configuring PAC I asked two questions … future projects will have
  different documents").
- **2026-10-15** — v1.1: greeting shows the usage guide; CHECKLIST.md (A–H + decision matrix); profiles/custom.md (core-lite) —
  owner (translated): "when I say 'hi', just show me how to use it; list a load checklist so I know how to onboard — product, PAC-like
  or custom — and propose the configuration".
